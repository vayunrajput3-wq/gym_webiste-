import { motion } from 'framer-motion';
import { FaInstagram, FaTwitter } from 'react-icons/fa';

export function Trainers() {
  const trainers = [
    {
      name: "Rahul Sharma",
      specialty: "Strength & Conditioning",
      experience: "8 Years Experience",
      image: "https://images.unsplash.com/photo-1571731956672-f2b94d7dd0cb?w=400&q=80",
      bio: "Former national level weightlifter specializing in building raw strength and athletic conditioning."
    },
    {
      name: "Priya Mehta",
      specialty: "Weight Loss Specialist",
      experience: "6 Years Experience",
      image: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&q=80",
      bio: "Dedicated to helping clients transform their bodies and relationship with food through sustainable habits."
    },
    {
      name: "Arjun Singh",
      specialty: "Functional Fitness",
      experience: "5 Years Experience",
      image: "https://images.unsplash.com/photo-1548690312-e3b507d8c110?w=400&q=80",
      bio: "CrossFit Level 2 trainer focused on mobility, longevity, and high-intensity functional training."
    },
    {
      name: "Neha Patel",
      specialty: "Yoga & Flexibility",
      experience: "7 Years Experience",
      image: "https://images.unsplash.com/photo-1556817411-31ae72fa3ea0?w=400&q=80",
      bio: "Certified Ashtanga Vinyasa instructor blending ancient wisdom with modern biomechanics."
    }
  ];

  return (
    <section id="trainers" className="py-24 bg-gray-50 dark:bg-[#0b1121]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Our Team</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-[#0F172A] dark:text-white uppercase">
              Meet Our Expert <span className="text-[#38BDF8]">Trainers</span>
            </h2>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {trainers.map((trainer, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl bg-white dark:bg-[#1e293b] shadow-lg"
            >
              <div className="aspect-[3/4] overflow-hidden relative">
                <img 
                  src={trainer.image} 
                  alt={trainer.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-[#0F172A]/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center">
                  <p className="text-white text-sm leading-relaxed mb-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    "{trainer.bio}"
                  </p>
                  <div className="flex space-x-4">
                    <a href="#" className="w-10 h-10 rounded-full bg-[#22C55E] text-white flex items-center justify-center hover:bg-white hover:text-[#22C55E] transition-colors">
                      <FaInstagram className="w-5 h-5" />
                    </a>
                    <a href="#" className="w-10 h-10 rounded-full bg-[#38BDF8] text-white flex items-center justify-center hover:bg-white hover:text-[#38BDF8] transition-colors">
                      <FaTwitter className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold text-[#0F172A] dark:text-white uppercase mb-1">{trainer.name}</h3>
                <p className="text-[#22C55E] font-medium text-sm mb-2">{trainer.specialty}</p>
                <p className="text-gray-500 dark:text-gray-400 text-sm">{trainer.experience}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
