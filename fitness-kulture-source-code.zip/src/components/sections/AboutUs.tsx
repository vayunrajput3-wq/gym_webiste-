import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

export function AboutUs() {
  return (
    <section id="about" className="py-24 bg-white dark:bg-[#0F172A]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          
          {/* Left: Image */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative z-10 aspect-[4/5] overflow-hidden rounded-2xl border-l-8 border-b-8 border-[#22C55E]">
              <img 
                src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800&q=80" 
                alt="Fitness Kulture Gym" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-[#0F172A]/20"></div>
            </div>
            
            {/* Decorative block */}
            <div className="absolute top-10 -right-10 w-2/3 h-2/3 bg-[#38BDF8]/10 dark:bg-[#38BDF8]/5 -z-10 rounded-2xl blur-2xl"></div>
          </motion.div>
          
          {/* Right: Content */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2"
          >
            <div className="mb-2">
              <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm">About Fitness Kulture Gym</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-extrabold mb-8 text-[#0F172A] dark:text-white uppercase">
              We Are <span className="text-[#22C55E]">Fitness</span> Kulture
            </h2>
            
            <div className="space-y-6 text-gray-600 dark:text-gray-300">
              <p className="text-lg">
                <strong className="text-[#0F172A] dark:text-white">Our Mission:</strong> Our mission is to empower every individual to reach their peak physical potential through world-class training, expert guidance, and a supportive community.
              </p>
              
              <p className="text-lg">
                <strong className="text-[#0F172A] dark:text-white">Our Vision:</strong> To be the most trusted fitness destination in India, where transformation is not just physical but mental and lifestyle-driven.
              </p>
            </div>
            
            <div className="mt-10 flex flex-col sm:flex-row gap-6">
              <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                <CheckCircle2 className="text-[#22C55E] w-8 h-8 flex-shrink-0" />
                <span className="font-bold text-[#0F172A] dark:text-white">10,000+ sq ft State-of-the-Art Facility</span>
              </div>
              <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                <CheckCircle2 className="text-[#22C55E] w-8 h-8 flex-shrink-0" />
                <span className="font-bold text-[#0F172A] dark:text-white">Open 365 Days a Year</span>
              </div>
            </div>
            
          </motion.div>

        </div>
      </div>
    </section>
  );
}
