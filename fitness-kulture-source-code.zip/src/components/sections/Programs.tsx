import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export function Programs() {
  const programs = [
    {
      title: "Strength Training",
      image: "https://images.unsplash.com/photo-1534367610401-9f5ed68180aa?w=600&q=80",
      description: "Build muscle mass and increase your strength with our comprehensive weight lifting programs."
    },
    {
      title: "Weight Loss",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=80",
      description: "Effective fat burning programs combining HIIT, cardio, and nutrition planning."
    },
    {
      title: "Cardio Training",
      image: "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?w=600&q=80",
      description: "Improve your cardiovascular health with our state-of-the-art endurance equipment."
    },
    {
      title: "Personal Training",
      image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80",
      description: "1-on-1 coaching customized completely to your unique body type and goals."
    },
    {
      title: "Functional Fitness",
      image: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80",
      description: "Train your body for real-life movements and improve your overall agility and balance."
    },
    {
      title: "Group Classes",
      image: "https://images.unsplash.com/photo-1571019613576-2b22c76fd955?w=600&q=80",
      description: "Join our energetic group sessions from Yoga and Pilates to Zumba and Crossfit."
    }
  ];

  return (
    <section id="programs" className="py-24 bg-gray-50 dark:bg-[#0b1121]">
      <div className="container mx-auto px-4 md:px-6">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Our Programs & Services</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-[#0F172A] dark:text-white uppercase">
              Transform <span className="text-[#38BDF8]">Your Way</span>
            </h2>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative h-[400px] overflow-hidden rounded-2xl cursor-pointer"
            >
              {/* Background Image */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url(${program.image})` }}
              ></div>
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/60 to-transparent"></div>

              {/* Content */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <h3 className="text-2xl font-bold text-white uppercase mb-2">{program.title}</h3>
                
                <div className="h-0 opacity-0 group-hover:h-auto group-hover:opacity-100 transition-all duration-500 overflow-hidden">
                  <p className="text-gray-300 mb-6">{program.description}</p>
                </div>
                
                <div className="flex items-center text-[#22C55E] font-bold uppercase tracking-wider text-sm mt-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <span>Learn More</span>
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-2 transition-transform" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
