import { useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useRef } from 'react';

function CountUp({ end, suffix = "" }: { end: number, suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const duration = 2000;
      const stepTime = Math.abs(Math.floor(duration / end));
      
      const timer = setInterval(() => {
        start += 1;
        setCount(start);
        if (start === end) clearInterval(timer);
      }, stepTime);
      
      return () => clearInterval(timer);
    }
  }, [end, isInView]);

  return <span ref={ref}>{count}{suffix}</span>;
}

export function Hero() {
  const stats = [
    { label: "Members", value: 500, suffix: "+" },
    { label: "Expert Trainers", value: 15, suffix: "+" },
    { label: "Programs", value: 50, suffix: "+" },
    { label: "Years Excellence", value: 5, suffix: "" },
  ];

  const scrollToSection = (id: string) => {
    document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#0F172A]/90 via-[#0F172A]/70 to-transparent dark:from-[#0F172A] dark:via-[#0F172A]/80 dark:to-transparent/50"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-3xl">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-extrabold text-white leading-tight mb-6 uppercase tracking-tight"
          >
            Transform Your Body, <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#22C55E] to-[#38BDF8]">Transform Your Life</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl"
          >
            Join Fitness Kulture Gym — where champions are made. Expert trainers, world-class equipment, and a community that pushes you beyond limits.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 mb-16"
          >
            <Button 
              size="lg" 
              onClick={() => scrollToSection('#membership')}
              className="bg-[#22C55E] hover:bg-[#1ca14b] text-white text-lg px-8 py-6 rounded-none border-none font-bold uppercase tracking-wider"
            >
              Join Now
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => scrollToSection('#contact')}
              className="border-2 border-white text-white hover:bg-white hover:text-[#0F172A] text-lg px-8 py-6 rounded-none font-bold uppercase tracking-wider bg-transparent"
            >
              Contact Us
            </Button>
          </motion.div>
          
          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 p-6 backdrop-blur-md bg-white/10 dark:bg-black/20 border border-white/10 rounded-2xl"
          >
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-extrabold text-[#22C55E] mb-1">
                  <CountUp end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-sm text-gray-300 uppercase font-semibold tracking-wider">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
