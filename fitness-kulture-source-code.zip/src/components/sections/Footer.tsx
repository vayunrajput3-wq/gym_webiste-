import { FaInstagram, FaFacebookF, FaYoutube, FaTwitter, FaWhatsapp } from 'react-icons/fa';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-gray-400 border-t border-[#22C55E]">
      <div className="container mx-auto px-4 md:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Brand */}
          <div className="space-y-6">
            <a href="#home" className="text-2xl font-extrabold tracking-tighter text-white inline-block">
              <span>CULTURE</span>
              <span className="text-[#22C55E]">FITNESS</span>
            </a>
            <p className="text-sm leading-relaxed text-gray-500">
              Premium fitness destination dedicated to transforming lives through expert training, modern facilities, and an unbeatable community spirit.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center hover:bg-[#22C55E] hover:text-white transition-colors">
                <FaInstagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center hover:bg-[#22C55E] hover:text-white transition-colors">
                <FaFacebookF className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center hover:bg-[#22C55E] hover:text-white transition-colors">
                <FaYoutube className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center hover:bg-[#22C55E] hover:text-white transition-colors">
                <FaTwitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="hover:text-[#22C55E] transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-[#22C55E] transition-colors">About Us</a></li>
              <li><a href="#trainers" className="hover:text-[#22C55E] transition-colors">Trainers</a></li>
              <li><a href="#membership" className="hover:text-[#22C55E] transition-colors">Membership</a></li>
              <li><a href="#gallery" className="hover:text-[#22C55E] transition-colors">Gallery</a></li>
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Programs</h4>
            <ul className="space-y-3">
              <li><a href="#programs" className="hover:text-[#22C55E] transition-colors">Strength Training</a></li>
              <li><a href="#programs" className="hover:text-[#22C55E] transition-colors">Weight Loss</a></li>
              <li><a href="#programs" className="hover:text-[#22C55E] transition-colors">Personal Training</a></li>
              <li><a href="#programs" className="hover:text-[#22C55E] transition-colors">Functional Fitness</a></li>
              <li><a href="#programs" className="hover:text-[#22C55E] transition-colors">Group Classes</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="text-[#22C55E] mr-3 mt-1">📍</span>
                <span>Fitness Kulture Gym, Mumbai,<br/>Maharashtra, India</span>
              </li>
              <li className="flex items-center">
                <span className="text-[#22C55E] mr-3">📞</span>
                <a href="tel:+919172836655" className="hover:text-white transition-colors">+91 9172836655</a>
              </li>
              <li className="flex items-center">
                <FaWhatsapp className="text-[#25D366] mr-3 text-lg" />
                <a href="https://wa.me/919172836655" className="hover:text-white transition-colors">WhatsApp Us</a>
              </li>
              <li className="flex items-center">
                <span className="text-[#22C55E] mr-3">✉️</span>
                <a href="mailto:info@culturefitness.in" className="hover:text-white transition-colors">info@culturefitness.in</a>
              </li>
            </ul>
          </div>

        </div>
      </div>
      
      {/* Copyright */}
      <div className="border-t border-gray-900 py-6">
        <div className="container mx-auto px-4 md:px-6 text-center text-sm text-gray-600">
          <p>© {currentYear} Fitness Kulture Gym. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
}
