import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: "Amit Kumar",
      text: "Fitness Kulture transformed my life completely. Lost 20kg in 6 months with expert guidance!",
      rating: 5,
      color: "bg-blue-500"
    },
    {
      name: "Sneha Joshi",
      text: "Best gym in the area! The trainers are incredibly supportive and the environment is world-class.",
      rating: 5,
      color: "bg-pink-500"
    },
    {
      name: "Raj Patel",
      text: "Joined for the equipment, stayed for the community. Best decision of my life!",
      rating: 5,
      color: "bg-purple-500"
    },
    {
      name: "Kavita Singh",
      text: "The personal training sessions are exceptional. My strength has doubled in 3 months.",
      rating: 5,
      color: "bg-orange-500"
    },
    {
      name: "Vikram Malhotra",
      text: "Premium facility at a reasonable price. The nutrition guidance alone is worth the membership.",
      rating: 5,
      color: "bg-[#22C55E]"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const nextSlide = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  const prevSlide = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section id="testimonials" className="py-24 bg-white dark:bg-[#0F172A] relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Testimonials</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-[#0F172A] dark:text-white uppercase">
              What Our Members <span className="text-[#38BDF8]">Say</span>
            </h2>
          </motion.div>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="overflow-hidden relative h-[300px] sm:h-[250px] md:h-[220px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 w-full"
              >
                <div className="bg-gray-50 dark:bg-[#1e293b] rounded-2xl p-8 md:p-10 shadow-lg text-center h-full flex flex-col justify-center">
                  <div className="flex justify-center space-x-1 mb-6">
                    {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[#22C55E] text-[#22C55E]" />
                    ))}
                  </div>
                  <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 italic mb-8 font-medium">
                    "{testimonials[currentIndex].text}"
                  </p>
                  <div className="flex items-center justify-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${testimonials[currentIndex].color}`}>
                      {testimonials[currentIndex].name.charAt(0)}
                    </div>
                    <div className="text-left">
                      <h4 className="font-bold text-[#0F172A] dark:text-white">{testimonials[currentIndex].name}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Gym Member</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="flex justify-center items-center mt-8 space-x-6">
            <button 
              onClick={prevSlide}
              className="w-10 h-10 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#22C55E] hover:text-white hover:border-[#22C55E] transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-[#22C55E] w-6' : 'bg-gray-300 dark:bg-gray-600'
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
            <button 
              onClick={nextSlide}
              className="w-10 h-10 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#22C55E] hover:text-white hover:border-[#22C55E] transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
