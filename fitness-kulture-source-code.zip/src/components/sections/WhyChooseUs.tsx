import { motion } from 'framer-motion';
import { Shield, Zap, User, Heart, Calendar, Sparkles } from 'lucide-react';

export function WhyChooseUs() {
  const features = [
    {
      icon: <Shield className="w-10 h-10 text-[#22C55E]" />,
      title: "Certified Trainers",
      description: "All our trainers are nationally certified with 5+ years of experience"
    },
    {
      icon: <Zap className="w-10 h-10 text-[#22C55E]" />,
      title: "Modern Equipment",
      description: "State-of-the-art equipment from world's leading brands"
    },
    {
      icon: <User className="w-10 h-10 text-[#22C55E]" />,
      title: "Personal Training",
      description: "One-on-one personalized training programs tailored to your goals"
    },
    {
      icon: <Heart className="w-10 h-10 text-[#22C55E]" />,
      title: "Nutrition Guidance",
      description: "Expert nutritionists to plan your diet for maximum results"
    },
    {
      icon: <Calendar className="w-10 h-10 text-[#22C55E]" />,
      title: "Flexible Membership",
      description: "Choose from daily, monthly, quarterly, or annual membership plans"
    },
    {
      icon: <Sparkles className="w-10 h-10 text-[#22C55E]" />,
      title: "Clean Environment",
      description: "Sanitized, spacious, and well-ventilated gym environment"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  return (
    <section id="why-us" className="py-24 bg-[#0F172A] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[#22C55E]/5 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-[#38BDF8]/5 rounded-full blur-[80px] pointer-events-none"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Why Choose Us</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white uppercase">
              The Culture <span className="text-[#38BDF8]">Difference</span>
            </h2>
          </motion.div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              variants={itemVariants}
              className="group bg-white/5 hover:bg-white/10 border border-white/10 backdrop-blur-sm rounded-2xl p-8 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(34,197,94,0.15)]"
            >
              <div className="w-20 h-20 bg-[#22C55E]/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#22C55E]/20 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 uppercase">{feature.title}</h3>
              <p className="text-gray-400 text-lg leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
