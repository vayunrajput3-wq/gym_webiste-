import { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, MapPin, Send } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="py-24 bg-[#0F172A] relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Contact Us</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white uppercase">
              Get In <span className="text-[#38BDF8]">Touch</span>
            </h2>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
          >
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-sm">
                <div className="w-12 h-12 bg-[#22C55E]/20 rounded-full flex items-center justify-center text-[#22C55E] mb-4">
                  <Phone className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Call Us</h3>
                <a href="tel:+919172836655" className="text-gray-400 hover:text-[#22C55E] transition-colors block mb-2">
                  +91 9172836655
                </a>
              </div>
              
              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-sm">
                <div className="w-12 h-12 bg-[#25D366]/20 rounded-full flex items-center justify-center text-[#25D366] mb-4">
                  <FaWhatsapp className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">WhatsApp</h3>
                <a href="https://wa.me/919172836655" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#25D366] transition-colors block mb-2">
                  Chat with us
                </a>
              </div>

              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-sm">
                <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center text-purple-500 mb-4">
                  <MapPin className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Location</h3>
                <p className="text-gray-400">Fitness Kulture Gym, Mumbai, Maharashtra, India</p>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="h-[250px] w-full rounded-2xl overflow-hidden border border-white/10 relative">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241317.11609823895!2d72.74109995709657!3d19.08219783958221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63aceef0c69%3A0xe0eac2a843b19572!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
                className="absolute inset-0 w-full h-full"
                style={{ border: 0 }} 
                allowFullScreen 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Google Maps Location"
              ></iframe>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold text-white mb-6 uppercase">Send us a message</h3>
            
            {isSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center min-h-[300px] text-center">
                <div className="w-16 h-16 bg-[#22C55E]/20 rounded-full flex items-center justify-center mb-4">
                  <Send className="w-8 h-8 text-[#22C55E]" />
                </div>
                <h4 className="text-2xl font-bold text-white mb-2">Message Sent!</h4>
                <p className="text-gray-400">Thank you for reaching out. We will get back to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-1">Full Name *</label>
                  <Input 
                    id="name" 
                    required 
                    placeholder="John Doe" 
                    className="bg-[#0F172A] border-gray-700 text-white placeholder:text-gray-600 focus-visible:ring-[#22C55E]"
                  />
                </div>
                
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-400 mb-1">Phone Number</label>
                    <Input 
                      id="phone" 
                      type="tel" 
                      placeholder="+91" 
                      className="bg-[#0F172A] border-gray-700 text-white placeholder:text-gray-600 focus-visible:ring-[#22C55E]"
                    />
                  </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-400 mb-1">Your Message *</label>
                  <Textarea 
                    id="message" 
                    required 
                    placeholder="How can we help you achieve your fitness goals?" 
                    className="min-h-[150px] bg-[#0F172A] border-gray-700 text-white placeholder:text-gray-600 focus-visible:ring-[#22C55E]"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full py-6 text-lg font-bold uppercase tracking-wider bg-[#22C55E] hover:bg-[#1ca14b] text-white border-none mt-4"
                >
                  Send Message
                </Button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
