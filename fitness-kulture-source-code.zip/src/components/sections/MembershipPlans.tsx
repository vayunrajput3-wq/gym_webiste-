import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function MembershipPlans() {
  const plans = [
    {
      name: "Basic",
      price: "999",
      period: "/month",
      features: [
        "Gym Access (6am-10pm)",
        "Locker Room",
        "Basic Equipment",
        "Free WiFi"
      ],
      isPopular: false
    },
    {
      name: "Standard",
      price: "1,999",
      period: "/month",
      features: [
        "24/7 Gym Access",
        "All Equipment",
        "2 PT Sessions/month",
        "Nutrition Consultation",
        "Group Classes",
        "Locker Room",
        "Free WiFi"
      ],
      isPopular: true
    },
    {
      name: "Premium",
      price: "3,499",
      period: "/month",
      features: [
        "24/7 VIP Access",
        "All Equipment",
        "Unlimited PT Sessions",
        "Dedicated Nutritionist",
        "All Group Classes",
        "Personal Locker",
        "Free WiFi",
        "Spa Access"
      ],
      isPopular: false
    }
  ];

  return (
    <section id="membership" className="py-24 bg-[#0F172A] relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-[#22C55E] font-bold uppercase tracking-widest text-sm mb-2 block">Membership Plans</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white uppercase">
              Choose Your <span className="text-[#38BDF8]">Plan</span>
            </h2>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative bg-[#1e293b] rounded-2xl p-8 flex flex-col h-full border ${
                plan.isPopular 
                  ? 'border-[#22C55E] shadow-[0_0_30px_rgba(34,197,94,0.2)] md:-translate-y-4 md:scale-105 z-10' 
                  : 'border-white/10'
              }`}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#22C55E] text-white px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              
              <div className="mb-8 text-center">
                <h3 className="text-2xl font-bold text-white mb-4 uppercase">{plan.name}</h3>
                <div className="flex items-baseline justify-center">
                  <span className="text-xl text-gray-400">₹</span>
                  <span className="text-5xl font-extrabold text-white mx-1">{plan.price}</span>
                  <span className="text-gray-400">{plan.period}</span>
                </div>
              </div>

              <div className="flex-grow space-y-4 mb-8">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-[#22C55E] mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>

              <Button 
                className={`w-full py-6 text-lg font-bold uppercase tracking-wider rounded-xl ${
                  plan.isPopular 
                    ? 'bg-[#22C55E] hover:bg-[#1ca14b] text-white border-none' 
                    : 'bg-transparent border-2 border-[#38BDF8] text-[#38BDF8] hover:bg-[#38BDF8] hover:text-white'
                }`}
              >
                Get Started
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
