import { useEffect, useState } from 'react';
import { motion, useScroll } from 'framer-motion';
import { FaWhatsapp } from 'react-icons/fa';
import { ArrowUp } from 'lucide-react';

export function FloatingElements() {
  const [showBackToTop, setShowBackToTop] = useState(false);
  const { scrollYProgress } = useScroll();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <>
      {/* Scroll Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1.5 bg-[#22C55E] origin-left z-50"
        style={{ scaleX: scrollYProgress }}
      />

      {/* Floating Actions Container */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-4">
        {/* Back to Top */}
        <motion.button
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ 
            opacity: showBackToTop ? 1 : 0, 
            scale: showBackToTop ? 1 : 0.5,
            pointerEvents: showBackToTop ? 'auto' : 'none'
          }}
          onClick={scrollToTop}
          className="w-12 h-12 bg-gray-800 dark:bg-gray-700 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors"
          aria-label="Back to top"
        >
          <ArrowUp className="w-6 h-6" />
        </motion.button>

        {/* WhatsApp Button */}
        <a 
          href="https://wa.me/919172836655" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-lg hover:bg-[#20ba56] transition-colors group relative"
          aria-label="Chat on WhatsApp"
        >
          <div className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-75"></div>
          <FaWhatsapp className="w-8 h-8 relative z-10" />
        </a>
      </div>
    </>
  );
}
